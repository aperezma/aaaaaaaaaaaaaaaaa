import '../../styles/components/layout/Footer.css'


const Footer = (props) => {
    return (
        <footer>
         <p>Web creada para un trabajo práctico</p>
        </footer>
    )
};
export default Footer;